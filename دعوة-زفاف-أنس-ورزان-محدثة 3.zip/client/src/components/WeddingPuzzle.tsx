import { useState, type KeyboardEvent } from "react";
import { Eye, EyeOff, RotateCcw, SkipForward, Sparkles } from "lucide-react";
import { PUZZLE_IMAGE } from "@/lib/puzzleArt";
import "@/puzzle.css";

// Three disjoint swaps from [0, 1, 2, 3, 4, 5]. Reversing them always solves it.
export const INITIAL_TILES = [1, 0, 5, 4, 3, 2] as const;
const confetti = Array.from({ length: 16 }, (_, index) => ({
  left: `${8 + (index * 41) % 85}%`,
  delay: `${(index % 5) * 0.12}s`,
  duration: `${1.25 + (index % 4) * 0.19}s`,
}));

interface WeddingPuzzleProps {
  solved: boolean;
  onSolved: () => void;
  onSkip: () => void;
  onReplay: () => void;
}

export default function WeddingPuzzle({ solved, onSolved, onSkip, onReplay }: WeddingPuzzleProps) {
  const [tiles, setTiles] = useState<number[]>([...INITIAL_TILES]);
  const [selected, setSelected] = useState<number | null>(null);
  const [moves, setMoves] = useState(0);
  const [showHint, setShowHint] = useState(false);

  const selectTile = (position: number) => {
    if (solved) return;
    if (selected === null) {
      setSelected(position);
      return;
    }
    if (selected === position) {
      setSelected(null);
      return;
    }
    const next = [...tiles];
    [next[selected], next[position]] = [next[position], next[selected]];
    setTiles(next);
    setSelected(null);
    setMoves((count) => count + 1);
    if (next.every((piece, index) => piece === index)) onSolved();
  };

  const handleTileKey = (event: KeyboardEvent<HTMLButtonElement>, position: number) => {
    const offsets: Record<string, number> = {
      ArrowRight: 1,
      ArrowLeft: -1,
      ArrowDown: 3,
      ArrowUp: -3,
    };
    if (!(event.key in offsets)) return;
    event.preventDefault();
    const next = position + offsets[event.key];
    const sameRow = Math.floor(next / 3) === Math.floor(position / 3);
    if (next >= 0 && next < 6 && (Math.abs(offsets[event.key]) === 3 || sameRow)) {
      event.currentTarget.parentElement?.querySelector<HTMLButtonElement>(`[data-position="${next}"]`)?.focus();
    }
  };

  return (
    <div className="puzzle-screen" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="puzzle-title">
      <div className="puzzle-ambient puzzle-ambient-one" aria-hidden="true" />
      <div className="puzzle-ambient puzzle-ambient-two" aria-hidden="true" />
      <div className="puzzle-shell">
        <div className="puzzle-monogram" aria-hidden="true">أ و ر</div>
        <p className="puzzle-kicker"><span /> أول الحكاية <span /></p>
        <h1 id="puzzle-title">رتّب الصورة <em>وافتح الدعوة</em></h1>
        <p className="puzzle-instruction">اضغط على قطعتين لتبديل مكانهما</p>
        <div className="puzzle-frame">
          <div className="puzzle-frame-head">
            <span><Sparkles size={13} aria-hidden="true" /> لحظة قبل الحكاية</span>
            <span dir="rtl">{moves.toLocaleString("ar")} {moves === 1 ? "حركة" : "حركات"}</span>
          </div>
          <div className="puzzle-board" dir="ltr" role="group" aria-label="لعبة ترتيب الصورة، صفّان وثلاثة أعمدة">
            {tiles.map((piece, position) => (
              <button
                key={position}
                type="button"
                className={`puzzle-tile ${selected === position ? "is-selected" : ""}`}
                data-position={position}
                data-piece={piece}
                aria-label={`الموضع ${position + 1}، القطعة ${piece + 1}${selected === position ? "، محددة" : ""}`}
                aria-pressed={selected === position}
                disabled={solved}
                onClick={() => selectTile(position)}
                onKeyDown={(event) => handleTileKey(event, position)}
                style={{
                  backgroundImage: `url("${PUZZLE_IMAGE}")`,
                  backgroundPosition: `${(piece % 3) * 50}% ${Math.floor(piece / 3) * 100}%`,
                }}
              >
                <span className="tile-selected-mark" aria-hidden="true" />
              </button>
            ))}
          </div>
          <div className="puzzle-frame-bottom">
            <span aria-live="polite">{solved ? "الصورة مكتملة" : selected === null ? "اختر القطعة الأولى" : "الآن اختر قطعة لتبديلها"}</span>
            <button className="hint-button" type="button" aria-expanded={showHint} aria-controls="puzzle-hint" onClick={() => setShowHint((visible) => !visible)}>
              {showHint ? <EyeOff size={15} /> : <Eye size={15} />}
              {showHint ? "إخفاء الصورة" : "عرض الصورة"}
            </button>
          </div>
        </div>
        {showHint && <div className="puzzle-hint" id="puzzle-hint"><img src={PUZZLE_IMAGE} alt="الصورة الكاملة: عروس محجّبة وعريس في إطار نباتي بلون المريمية" /><span>الصورة الكاملة</span></div>}
        <div className="puzzle-foot">
          <button className="puzzle-skip" type="button" onClick={onSkip}><SkipForward size={14} aria-hidden="true" /> تخطّي اللعبة</button>
          <span className="puzzle-foot-divider" aria-hidden="true" />
          <button className="puzzle-replay" type="button" onClick={onReplay}><RotateCcw size={14} aria-hidden="true" /> إعادة اللعبة</button>
        </div>
        <p className="puzzle-signature">أنس <span>♥</span> رزان · ١٠ ديسمبر ٢٠٢٦</p>
      </div>
      {solved && (
        <div className="puzzle-success" role="status" aria-live="assertive">
          <div className="confetti-field" aria-hidden="true">
            {confetti.map((piece, index) => <i key={index} style={{ left: piece.left, animationDelay: piece.delay, animationDuration: piece.duration }} />)}
          </div>
          <span className="success-seal" aria-hidden="true">أ و ر</span>
          <strong>اكتملت الصورة… وبلشت الحكاية</strong>
          <small>دعوتكم تنتظركم</small>
        </div>
      )}
    </div>
  );
}
