import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  CalendarDays,
  Check,
  Clock3,
  Heart,
  MapPin,
  MessageCircleHeart,
  RotateCcw,
  Share2,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";
import WeddingPuzzle from "@/components/WeddingPuzzle";
import { PUZZLE_IMAGE } from "@/lib/puzzleArt";

type IntroStage = "closed" | "opening" | "gone";
type GateStage = "puzzle" | "solved" | "envelope";

const schedule = [
  { time: "٨:٠٠ م", title: "الاحتفال", note: "نلتقي لنشارك أنس ورزان فرحتهما" },
];

const WEDDING_TIMESTAMP = Date.UTC(2026, 11, 10, 17, 0, 0); // 8:00 PM in Amman (UTC+3)

function getCountdownUnits(now = Date.now()) {
  const secondsLeft = Math.max(0, Math.floor((WEDDING_TIMESTAMP - now) / 1000));
  return [
    { label: "يوم", value: Math.floor(secondsLeft / 86400) },
    { label: "ساعة", value: Math.floor((secondsLeft % 86400) / 3600) },
    { label: "دقيقة", value: Math.floor((secondsLeft % 3600) / 60) },
    { label: "ثانية", value: secondsLeft % 60 },
  ];
}

function WeddingCountdown() {
  const [units, setUnits] = useState(() => getCountdownUnits());

  useEffect(() => {
    const timer = window.setInterval(() => setUnits(getCountdownUnits()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const hasArrived = units.every((unit) => unit.value === 0);

  return (
    <div className="countdown-card reveal">
      <p className="mini-kicker">العد التنازلي</p>
      {hasArrived ? (
        <p className="countdown-arrived">حان موعد فرحتنا، أهلًا بكم</p>
      ) : (
        <>
          <div className="countdown-units" role="timer" aria-label="الوقت المتبقي حتى زفاف أنس ورزان">
            {units.map((unit) => (
              <div className="countdown-unit" key={unit.label}>
                <strong>{unit.value.toLocaleString("ar-JO", { minimumIntegerDigits: 2, useGrouping: false })}</strong>
                <span>{unit.label}</span>
              </div>
            ))}
          </div>
          <p className="countdown-caption">حتى نلتقي على الفرح</p>
        </>
      )}
    </div>
  );
}

function Ornament({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 200 72" fill="none" aria-hidden="true">
      <path d="M99 65C97 43 78 20 53 8C39 2 23 2 9 8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M101 65C103 43 122 20 147 8C161 2 177 2 191 8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M76 42C66 31 52 28 43 29C48 38 58 45 70 45" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <path d="M124 42C134 31 148 28 157 29C152 38 142 45 130 45" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <path d="M100 64V10" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <path d="M100 24C90 17 82 17 77 19C82 27 90 29 99 27" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <path d="M100 35C110 28 118 28 123 30C118 38 110 40 101 38" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
    </svg>
  );
}

function SealMark() {
  return (
    <span className="seal-mark" aria-hidden="true">
      أ و ر
    </span>
  );
}

export default function Home() {
  const [gateStage, setGateStage] = useState<GateStage>("puzzle");
  const [puzzleRun, setPuzzleRun] = useState(0);
  const [introStage, setIntroStage] = useState<IntroStage>("closed");
  const [isScrolled, setIsScrolled] = useState(false);
  const [attendance, setAttendance] = useState<"yes" | "later" | null>(null);
  const observerRoot = useRef<HTMLDivElement>(null);
  const transitionTimer = useRef<number | null>(null);
  const envelopeTimer = useRef<number | null>(null);
  const overlayActive = gateStage !== "envelope" || introStage !== "gone";

  useEffect(() => {
    document.body.style.overflow = overlayActive ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [overlayActive]);

  useEffect(() => () => {
    if (transitionTimer.current) clearTimeout(transitionTimer.current);
    if (envelopeTimer.current) clearTimeout(envelopeTimer.current);
  }, []);

  useEffect(() => {
    const updateHeader = () => setIsScrolled(window.scrollY > 34);
    window.addEventListener("scroll", updateHeader, { passive: true });
    updateHeader();
    return () => window.removeEventListener("scroll", updateHeader);
  }, []);

  useEffect(() => {
    const root = observerRoot.current;
    if (!root) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("is-visible");
        });
      },
      { threshold: 0.13 },
    );

    root.querySelectorAll(".reveal").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  const replayPuzzle = () => {
    if (transitionTimer.current) clearTimeout(transitionTimer.current);
    if (envelopeTimer.current) clearTimeout(envelopeTimer.current);
    setPuzzleRun((run) => run + 1);
    setGateStage("puzzle");
    setIntroStage("closed");
    setAttendance(null);
    window.scrollTo({ top: 0, behavior: "instant" });
  };

  const solvePuzzle = () => {
    setGateStage("solved");
    transitionTimer.current = window.setTimeout(() => {
      setGateStage("envelope");
      setIntroStage("closed");
    }, 1700);
  };

  const skipPuzzle = () => {
    if (transitionTimer.current) clearTimeout(transitionTimer.current);
    setGateStage("envelope");
    setIntroStage("closed");
  };

  const openEnvelope = () => {
    if (introStage !== "closed") return;
    setIntroStage("opening");
    envelopeTimer.current = window.setTimeout(() => setIntroStage("gone"), 1450);
  };

  const saveTheDate = () => {
    const event = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "BEGIN:VEVENT",
      "UID:anas-razan-2026@invitation",
      "DTSTAMP:20100101T000000Z",
      "DTSTART:20261210T200000",
      "DTEND:20261210T230000",
      "SUMMARY:زفاف أنس ورزان",
      "LOCATION:Le Royal Hotel Amman",
      "DESCRIPTION:ننتظركم لمشاركة أنس ورزان فرحتهما.",
      "END:VEVENT",
      "END:VCALENDAR",
    ].join("\r\n");
    const blob = new Blob([event], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "anas-razan-wedding.ics";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    toast.success("أضيف الموعد إلى تقويمك", { description: "ننتظركم في ليلة لا تُنسى." });
  };

  const shareInvitation = async () => {
    const shareData = {
      title: "دعوة زفاف أنس ورزان",
      text: "يسعدنا دعوتكم لمشاركتنا فرحة زفاف أنس ورزان",
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success("تم نسخ رابط الدعوة");
      }
    } catch {
      // Closing a native share sheet is intentionally silent.
    }
  };

  const respond = (answer: "yes" | "later") => {
    setAttendance(answer);
    toast(answer === "yes" ? "يا أهلاً بكم، ستزداد ليلتنا فرحًا بوجودكم" : "يسعدنا أن تخبرونا بتأكيدكم لاحقًا", {
      description: answer === "yes" ? "شكرًا لمشاركتنا هذه الذكرى الجميلة." : "ستبقى دعوتكم محفوظة بكل محبة.",
    });
  };

  return (
    <div ref={observerRoot} className="invitation-page" dir="rtl">
      <header inert={overlayActive} className={`topbar ${isScrolled ? "topbar-scrolled" : ""}`}>
        <button className="brand-mark" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="العودة إلى البداية">
          أ <span>و</span> ر
        </button>
        <div className="topbar-actions">
          <button className="icon-action" onClick={replayPuzzle} aria-label="إعادة اللعبة"><RotateCcw size={17} strokeWidth={1.75} /></button>
          <button className="icon-action" onClick={shareInvitation} aria-label="مشاركة الدعوة"><Share2 size={18} strokeWidth={1.75} /></button>
        </div>
      </header>

      <main inert={overlayActive}>
        <section className="hero-section" id="start">
          <div className="hero-haze hero-haze-one" />
          <div className="hero-haze hero-haze-two" />
          <div className="fine-noise" />
          <div className="hero-inner">
            <p className="eyebrow reveal is-visible"><Sparkles size={14} /> بِسْمِ اللهِ الرَّحْمَنِ الرَّحِيمِ <Sparkles size={14} /></p>
            <p className="verse reveal is-visible">وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا</p>
            <div className="names-lockup reveal is-visible">
              <span>أنس</span>
              <Heart className="names-heart" size={19} fill="currentColor" />
              <span>رزان</span>
            </div>
            <div className="hero-rule reveal is-visible"><span /> <i>10</i> <span /></div>
            <p className="date-line reveal is-visible">الخميس · ١٠ ديسمبر · ٢٠٢٦</p>
            <button className="scroll-cue reveal is-visible" onClick={() => document.getElementById("invitation")?.scrollIntoView({ behavior: "smooth" })}>
              <span>اكتشف تفاصيل دعوتنا</span>
              <ArrowDown size={17} />
            </button>
          </div>
          <div className="hero-botanical botanical-right" aria-hidden="true"><span /><span /><span /><span /></div>
          <div className="hero-botanical botanical-left" aria-hidden="true"><span /><span /><span /></div>
        </section>

        <section className="welcome-section" id="invitation">
          <div className="section-wash" />
          <div className="content-column">
            <div className="section-lead reveal">
              <p className="mini-kicker">دعوتنا إليكم</p>
              <Ornament className="ornament" />
              <h1>ليلةٌ تبدأ بكم</h1>
              <p className="invitation-copy">بكل المحبة والامتنان، يسرّنا أن نشارككم بداية حكايتنا، وأن نجعل حضوركم أجمل ما فيها.</p>
            </div>

            <article className="couple-card reveal">
              <div className="photo-frame">
                <img src={PUZZLE_IMAGE} alt="رسم للعروس المحجّبة والعريس بين أغصان المريمية" />
                <div className="photo-overlay" />
                <p>على موعدٍ<br />مع الفرح</p>
              </div>
              <div className="card-names">
                <p>العريس والعروس</p>
                <h2>أنس <span>و</span> رزان</h2>
                <p>يبدآن فصلًا جديدًا بكل الحب</p>
              </div>
            </article>
          </div>
        </section>

        <section className="details-section">
          <div className="content-column">
            <div className="details-heading reveal">
              <p className="mini-kicker">تفاصيل الأمسية</p>
              <h2>نلتقي على الفرح</h2>
            </div>

            <div className="details-card reveal">
              <div className="detail-row">
                <span className="detail-icon"><CalendarDays size={20} /></span>
                <div><small>التاريخ</small><strong>الخميس، ١٠ ديسمبر ٢٠٢٦</strong></div>
              </div>
              <div className="detail-divider" />
              <div className="detail-row">
                <span className="detail-icon"><Clock3 size={20} /></span>
                <div><small>الوقت</small><strong>الثامنة مساءً</strong></div>
              </div>
              <div className="detail-divider" />
              <div className="detail-row">
                <span className="detail-icon"><MapPin size={20} /></span>
                <div><small>المكان</small><strong>Le Royal Hotel Amman</strong></div>
              </div>
              <button className="calendar-button" onClick={saveTheDate}>
                <CalendarDays size={17} /> <span>أضف الموعد إلى تقويمك</span>
              </button>
            </div>

            <WeddingCountdown />

            <div className="timeline reveal">
              {schedule.map((item, index) => (
                <div className="timeline-item" key={item.time}>
                  <div className="timeline-dot"><span>{index + 1}</span></div>
                  <div className="timeline-content"><time>{item.time}</time><h3>{item.title}</h3><p>{item.note}</p></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="note-section">
          <div className="note-quote reveal">
            <span className="quote-mark">“</span>
            <p>وجودكم حولنا هو الهدية التي ننتظرها،<br />فكونوا معنا لنصنع ذكرى تُحكى.</p>
            <span className="signature">أنس ورزان</span>
          </div>
          <Ornament className="note-ornament reveal" />
        </section>

        <section className="rsvp-section">
          <div className="content-column">
            <div className="rsvp-card reveal">
              <div className="rsvp-icon"><MessageCircleHeart size={24} /></div>
              <p className="mini-kicker">ننتظركم</p>
              <h2>هل ستشاركوننا الفرح؟</h2>
              <p className="rsvp-copy">يكفينا أن تؤكدوا حضوركم لنجهز لكم مكانًا في قلب هذه الليلة.</p>
              <div className="rsvp-actions">
                <button className={`primary-rsvp ${attendance === "yes" ? "selected" : ""}`} onClick={() => respond("yes")}>
                  {attendance === "yes" ? <Check size={18} /> : <Heart size={17} fill="currentColor" />} سأكون معكم
                </button>
                <button className={`secondary-rsvp ${attendance === "later" ? "selected" : ""}`} onClick={() => respond("later")}>سأؤكد لاحقًا</button>
              </div>
              <p className="rsvp-hint">نرجو تأكيد حضوركم مسبقًا</p>
            </div>
          </div>
        </section>
      </main>

      <footer inert={overlayActive}>
        <SealMark />
        <p>بكل الحب، ننتظركم</p>
        <span>أنس × رزان</span>
      </footer>

      {gateStage === "envelope" && introStage !== "gone" && (
        <div className={`envelope-screen ${introStage === "opening" ? "is-opening" : ""}`}>
          <div className="envelope-scene">
            <p className="envelope-kicker" style={{fontSize: '20px', fontWeight: '800'}}>دعوة خاصة لك</p>
            <button className="envelope" onClick={openEnvelope} aria-label="افتح الظرف لاستكشاف الدعوة">
              <span className="envelope-shadow" />
              <span className="envelope-back" />
              <span className="envelope-letter"><span>أنس <i>×</i> رزان</span><small>دعوة زفاف</small></span>
              <span className="envelope-flap" />
              <span className="envelope-front"><i /><b /></span>
              <SealMark />
            </button>
            <p className="open-prompt">اضغط لفتح الظرف <ChevronHint /></p>
            <div className="entry-note" role="note" aria-label="تنويه الحضور">
              <strong>هذه الدعوة مخصصة لشخصين فقط</strong>
              <span>نعتذر عن اصطحاب الأطفال</span>
            </div>
            <button className="envelope-replay" onClick={replayPuzzle}><RotateCcw size={14} /> إعادة اللعبة</button>
          </div>
        </div>
      )}
      {gateStage !== "envelope" && <WeddingPuzzle key={puzzleRun} solved={gateStage === "solved"} onSolved={solvePuzzle} onSkip={skipPuzzle} onReplay={replayPuzzle} />}
    </div>
  );
}

function ChevronHint() {
  return <span className="chevron-hint">⌄</span>;
}
