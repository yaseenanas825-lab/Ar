// A self-contained vector illustration: no remote image request is needed for the puzzle.
const portrait = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" width="900" height="600">
<defs>
 <linearGradient id="paper" x2="1" y2="1"><stop stop-color="#eee8d8"/><stop offset="1" stop-color="#cbd7c7"/></linearGradient>
 <linearGradient id="arch" x2="1" y2="1"><stop stop-color="#e8e9d9"/><stop offset="1" stop-color="#b6c9b2"/></linearGradient>
 <linearGradient id="dress" x2="1" y2="1"><stop stop-color="#fffdf3"/><stop offset="1" stop-color="#e7dfc9"/></linearGradient>
 <linearGradient id="suit" x2="1" y2="1"><stop stop-color="#425c49"/><stop offset="1" stop-color="#223d30"/></linearGradient>
 <radialGradient id="glow"><stop stop-color="#fff6dc" stop-opacity=".9"/><stop offset="1" stop-color="#fff6dc" stop-opacity="0"/></radialGradient>
</defs>
<rect width="900" height="600" fill="url(#paper)"/>
<circle cx="450" cy="200" r="325" fill="url(#glow)"/>
<path d="M143 600V268C143 98 274 31 450 31S757 98 757 268V600" fill="#f5f0e2" stroke="#b9985e" stroke-width="3"/>
<path d="M159 600V271C159 117 285 48 450 48S741 117 741 271V600" fill="url(#arch)" stroke="#f7f1dc" stroke-width="2"/>
<path d="M178 600V270C178 142 290 67 450 67S722 142 722 270V600" fill="none" stroke="#d9c69c" stroke-width="1.5" opacity=".7"/>
<path d="M0 600C92 485 114 327 103 155M900 600C810 478 785 322 797 156" fill="none" stroke="#718d73" stroke-width="5" opacity=".7"/>
<g fill="#8fa890" opacity=".78">
 <ellipse cx="58" cy="435" rx="19" ry="53" transform="rotate(38 58 435)"/><ellipse cx="104" cy="363" rx="19" ry="55" transform="rotate(-32 104 363)"/><ellipse cx="64" cy="276" rx="16" ry="47" transform="rotate(44 64 276)"/><ellipse cx="104" cy="214" rx="17" ry="45" transform="rotate(-35 104 214)"/>
 <ellipse cx="843" cy="439" rx="19" ry="53" transform="rotate(-38 843 439)"/><ellipse cx="797" cy="361" rx="19" ry="55" transform="rotate(32 797 361)"/><ellipse cx="837" cy="275" rx="16" ry="47" transform="rotate(-44 837 275)"/><ellipse cx="797" cy="213" rx="17" ry="45" transform="rotate(35 797 213)"/>
</g>
<g fill="#d2b573" opacity=".88"><circle cx="101" cy="491" r="8"/><circle cx="68" cy="345" r="7"/><circle cx="790" cy="489" r="8"/><circle cx="832" cy="342" r="7"/><circle cx="205" cy="139" r="4"/><circle cx="690" cy="154" r="4"/></g>
<g stroke="#d6bd82" stroke-width="2" stroke-linecap="round" opacity=".75"><path d="M450 79v13m-7-7h14M675 243v12m-6-6h12M230 288v12m-6-6h12"/></g>
<!-- groom: tailored sage jacket, white shirt, warm skin, dark hair -->
<path d="M223 352Q266 316 310 318Q362 314 406 358L433 600H177Z" fill="url(#suit)" stroke="#d8d0b0" stroke-width="2"/>
<path d="M277 332L314 397L342 331L330 313H291Z" fill="#faf5e6"/>
<path d="M309 379l-9 17 12 117 12-117-11-17Z" fill="#bc9a5e"/>
<path d="M259 332l53 112-49-25-21 22M362 332l-50 112 52-26 20 24" fill="none" stroke="#88a18a" stroke-width="5"/>
<path d="M289 283v54q22 31 48 0v-54" fill="#d7a884"/>
<ellipse cx="313" cy="237" rx="57" ry="72" fill="#dbae8d"/>
<path d="M255 226q-4-65 51-73 66-12 70 55l-12 35-7-33q-31 7-61-9-17 18-39 20Z" fill="#303c34"/>
<path d="M256 222q-8-46 23-65 23-14 51-7 33 9 42 44-26-15-46-18-21 27-70 46Z" fill="#303c34"/>
<path d="M286 249q8-5 17 0m24 0q8-5 17 0" fill="none" stroke="#4b4134" stroke-width="3" stroke-linecap="round"/>
<path d="M307 280q8 7 17 0" fill="none" stroke="#955e57" stroke-width="2.5" stroke-linecap="round"/>
<path d="M400 383q43 27 64 85l-23 20q-35-36-67-52" fill="#35523d"/>
<!-- bride: full ivory hijab, veil and flowing gown -->
<path d="M459 265Q474 111 551 124q99-4 120 155l106 321H365Z" fill="#f7f2e6" opacity=".86" stroke="#e9dcbf" stroke-width="3"/>
<path d="M486 328Q528 307 572 322q88 13 116 115l83 163H379l67-174q17-66 40-98Z" fill="url(#dress)" stroke="#d9c9a7" stroke-width="3"/>
<path d="M473 376q89 68 196-2M424 562q140-62 301 1" fill="none" stroke="#dccba9" stroke-width="2" opacity=".8"/>
<path d="M512 289v52q38 29 70-1v-51" fill="#d8a886"/>
<ellipse cx="546" cy="236" rx="56" ry="70" fill="#e0b493"/>
<path d="M487 232q-10-78 52-94 69-14 86 67 4 23-1 45l-24-25q-22-6-33-29-21 24-70 32l-10 29Z" fill="#faf6e8" stroke="#e9ddc7" stroke-width="2"/>
<path d="M490 242q-2 59 24 91-13 23-42 41-21-69 3-127Z" fill="#fffaf0"/>
<path d="M612 225q16 51-22 111l32 39q27-49 15-105Z" fill="#fffaf0"/>
<path d="M519 251q8-5 17 0m27 0q8-5 17 0" fill="none" stroke="#5c493d" stroke-width="3" stroke-linecap="round"/>
<path d="M539 283q8 6 17 0" fill="none" stroke="#ad7568" stroke-width="2.5" stroke-linecap="round"/>
<path d="M583 344q-7 18-36 32-29-17-34-32" fill="none" stroke="#c9ac78" stroke-width="2.5"/>
<path d="M473 408q-21 21-34 60l26 17 60-51M632 400q22 24 31 68l-29 17-56-48" fill="#f7f0df" stroke="#ddcdb1" stroke-width="2"/>
<!-- bouquet between them -->
<path d="M474 460l39 99m5-100-7 100m42-102-39 102" fill="none" stroke="#688970" stroke-width="4"/>
<g fill="#f8f2df" stroke="#c8a96e" stroke-width="2"><circle cx="463" cy="450" r="24"/><circle cx="501" cy="436" r="29"/><circle cx="538" cy="447" r="25"/><circle cx="483" cy="472" r="22"/><circle cx="521" cy="476" r="24"/></g>
<g fill="#d2ad76"><circle cx="463" cy="450" r="6"/><circle cx="501" cy="436" r="7"/><circle cx="538" cy="447" r="6"/><circle cx="483" cy="472" r="5"/><circle cx="521" cy="476" r="6"/></g>
<path d="M451 484q-44-9-64-40 33-2 64 40m90 2q42-22 58-50-33 4-58 50" fill="#8ca88a"/>
<path d="M0 571Q187 543 332 574T900 570v30H0Z" fill="#708c73" opacity=".25"/>
</svg>`;

export const PUZZLE_IMAGE = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(portrait)}`;
